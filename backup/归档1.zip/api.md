###1.管理员注册 √


> 只有超级管理员才能进行注册  

#### 请求URL
```
post /api/v1/admin/signup 
```
#### 参数类型: query

参数|是否必选|类型|备注
---|---|---|---
|username | 是 | string| 用户名
|password | 是 | string|  密码
#### 返回示例
```
{
	status: 1,
	message: '注册管理员成功'
}

```

###2.管理员登录 √
#### 请求URL
```
POST /api/v1/admin/signin
```
#### 参数类型: query

参数|是否必选|类型|备注
---|---|---|---
|username | 是 | string| 用户名
|password | 是 | string|  密码
#### 返回示例
```
{"status":1,
	"message":"登录成功",
	"data":{
		"user":{
			"username":"admin",
			"avatar_url":"http://www.icosky.com/icon/png/System/Scrap/Administrator%202.png",
			"created_time":"2017-07-06T06:39:13.933Z",
			"is_super":true,
			"id":1
		}
	}
}

```

###3.管理员注销 √

#### 请求URL
```
post /api/v1/admin/signout 
```
#### 参数类型:

参数|是否必选|类型|备注
---|---|---|---
#### 返回示例
```
{
	status: 1,
	message: '注销成功'
}

```

###4. 查询管理员数量 √
 

#### 请求URL
```
GET /api/v1/admin/count
```
#### 参数类型:

参数|是否必选|类型|备注
---|---|---|---
#### 返回示例
```
{
	status: 1,
	message: '查询管理员数量成功',
	data: 20
}

```

###5.获取管理员列表 √

#### 请求URL
```
 GET api/v1/admin/accounts  
```
#### 参数类型: query

参数|是否必选|类型|备注
---|---|---|---
|limit | 否 | number| 每页多少个（默认为20） 
|page | 否 | number|  第几页（默认为1）
#### 返回示例
```
{
	"status": 1,
	"message": "查询管理员账户成功",
	"data": [{
		"username": "admin",
		"id": 1,
		"created_time": "2017-07-06T06:39:13.933Z",
		"is_super": true
	}]
}

```


###6.更新管理员头像 √
> 使用 multipart/form-data 后期应使用http://www.xx.com/8080:/public这样的绝对路径

#### 请求URL
```
 POST api/v1/admin/avatar/update
```
#### 参数类型:

参数|是否必选|类型|备注
---|---|---|---

#### 返回示例

```
{
	"status": 1,
	"message": "上传头像成功",
	"avatar_url": "/public/images/admin/avatar/upload/460eb77035fc71e7d86168699eee126e.jpg"
}

```
###7.添加商品分类 
> 一次只能添加一个分类

#### 请求URL
```
POST /api/v1/goods_categories
```
#### 参数类型:

参数|是否必选|类型|备注
---|---|---|---
|category_name|是|String|分类的名称

#### 返回示例

```
{
	"status": 1,
	"message": "添加分类成功",
	"data": {
		"category_name": "塑胶管",
		"id": 2,
		"created_time": "2017-07-24T09:21:20.700Z"
	}
}
```
###8.查询商品分类(所有的)

#### 请求URL
```
GET /api/v1/goods_categories
```
#### 参数类型:

参数|是否必选|类型|备注
---|---|---|---

#### 返回示例

```
{
	"status": 1,
	"message": "查询分类成功",
	"data": [{
		"category_name": "塑胶管",
		"id": 1,
		"created_time": "2017-07-24T09:26:40.331Z"
	}]
}

```

###9.查询商品分类数量

#### 请求URL
```
GET /api/v1/goods_categories/count 
```
#### 参数类型:

参数|是否必选|类型|备注
---|---|---|---

#### 返回示例

```
{
	"status": 1,
	"message": "查询分类数量成功",
	"data": 1
}

```

---

* 添加商品 post /goods/add
* 删除商品 post /goods/:id/delete (超级管理员)
* 修改商品 post /goods/:id/update
* 出售商品 post /goods/:id/sale
* 查询商品数量 get /goods/count 
* 查询单个商品 get /goods/:id 
* 查询商品 get /goods/?name=foo&category_id=123&limit=20&page=1  (按分类或者按关键字查询,默认20个)
* 查询商品图文 get /goods/:id/detail
* 修改商品图文 post /goods/:id/detail