export default {
	username: 'admin',
	password: "96e79218965eb72c92a549dd5a330112", // 111111 的md5 hex加密
	id: 1,
	created_time: "2017-07-06T06:39:13.933Z", //iso
	is_super: true // 是否超级管理员
}