var express = require('express');
var router = express.Router();
// import Admin from "../../../controller/v1/admin.js"

//  GET users listing. 
// router.get('/signup', Admin.signup);

export default router;