// 路由
import admin from "./api/v1/admin.js"
import goods_categories from "./api/v1/goods_categories.js"
import goods from "./api/v1/goods.js"

const router = (app) => {
	app.use("/api/v1/admin", admin);
	app.use("/api/v1/goods_categories", goods_categories);
	app.use("/api/v1/goods", goods);
};

export default router;
