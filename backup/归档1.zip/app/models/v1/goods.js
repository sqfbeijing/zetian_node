import mongoose from 'mongoose'

let Schema = mongoose.Schema;
let goods = Schema({
	name: String,
	id: Number,
	creater_id: Number, // 创建人（管理员的id）
	created_time: String, //iso
	serial_number: String, //手动输入的商品编号
	unit: String, // 单位
	price: Number,
	category_id: Number,
	putaway_time: String, //iso 上架时间
	store: Array, // 所属店铺, 每一项是个数字（店铺id）
	warehouse: Array, // 所属库房, 每一项是个数字（库房id）
	sold_count: {type: Number, default: 0},
	inventory: {type: Number, default: 0}, // 库存
	tags: Array, // 标签id
	image_url: String, // 唯一的图片标示url
	description: String
});

let Goods = mongoose.model("Goods", goods);

export default Goods;