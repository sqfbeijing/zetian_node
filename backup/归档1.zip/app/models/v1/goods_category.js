import mongoose from 'mongoose'

let Schema = mongoose.Schema;
let goods_categorySchema = Schema({
	category_name: String,
	id: Number,
	created_time: String //iso
});

let GoodsCategory = mongoose.model("GoodsCategory", goods_categorySchema);

export default GoodsCategory;

